﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Factory
{
    public class FoodFactory
    {
    }
}
