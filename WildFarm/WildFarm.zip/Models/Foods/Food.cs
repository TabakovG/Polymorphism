﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Models.Foods
{
    public abstract class Food
    {
        //no need to implement food classes and factory FOR NOW

        public int Quantity { get; }
    }
}
